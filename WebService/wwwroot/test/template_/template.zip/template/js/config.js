const center = { 
   lat: 52.5159, 
   lng: 13.3777, 
   text: 'Berlin, Germany'
}

const hereCredentials = {
   id: 'YOUR-HERE-ID',
   code: 'YOUR-HERE-CODE',
   apikey: 'YOUR-HERE-APIKEY'
}

export { center, hereCredentials };